import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {Window} from 'happy-dom';
import {startExperience} from './experience-startup.mjs';

test('actual application entry starts against the shipped HTML and renders navigation and Home', async () => {
 const window = new Window({url:'http://localhost/',settings:{disableJavaScriptEvaluation:true,disableCSSFileLoading:true,disableJavaScriptFileLoading:true}});
 const html = await readFile(new URL('./index.html',import.meta.url),'utf8');
 window.document.write(html);
 const names=['window','document','location','history','localStorage','sessionStorage','matchMedia','getComputedStyle','requestAnimationFrame','cancelAnimationFrame','HTMLElement','HTMLInputElement','HTMLSelectElement','Element','Node','CSS'];
 const saved = new Map(names.map(name=>[name,Object.getOwnPropertyDescriptor(globalThis,name)]));
 for(const name of names){const value=name==='window'?window:typeof window[name]==='function'&&!/^[A-Z]/.test(name)?window[name].bind(window):window[name];Object.defineProperty(globalThis,name,{configurable:true,writable:true,value});}
 const interval=globalThis.setInterval;
 globalThis.setInterval=(...args)=>{const timer=interval(...args);timer.unref();return timer;};
 try {
  await import('./experience-boot.mjs?startup-test');
  assert.equal(document.querySelectorAll('#navigation a').length,13);
  assert.ok(document.querySelector('#page h1')?.textContent.trim());
  assert.ok(document.querySelector('#page [data-task-row]'));
  assert.ok(document.querySelector('.notification-trigger'));
 } finally {
  globalThis.setInterval=interval;
  await window.happyDOM.close();
  for(const [name,descriptor]of saved)if(descriptor)Object.defineProperty(globalThis,name,descriptor);else delete globalThis[name];
 }
});

test('startup failure shows an escaped, bilingual error without modifying saved records',async()=>{
 for(const language of ['en','id']){
  const window=new Window();
  window.document.body.innerHTML='<main id="page"></main>';
  window.document.documentElement.lang=language;
  window.localStorage.setItem('existing-records','preserve-me');
  const log=console.error;console.error=()=>{};
  try{
   const ok=await startExperience(()=>Promise.reject(new Error('<img src=x onerror=alert(1)>')),window.document);
   assert.equal(ok,false);
   assert.ok(window.document.querySelector('[role=alert]'));
   assert.equal(window.document.querySelector('pre').textContent,'<img src=x onerror=alert(1)>');
   assert.equal(window.document.querySelectorAll('img').length,0);
   assert.equal(window.localStorage.getItem('existing-records'),'preserve-me');
   assert.equal(window.document.querySelector('button').textContent,language==='id'?'Coba lagi':'Try again');
  }finally{console.error=log;await window.happyDOM.close();}
 }
});

test('opening index directly shows local-preview guidance instead of an empty shell',async()=>{
 const window=new Window({settings:{disableJavaScriptEvaluation:true,disableCSSFileLoading:true,disableJavaScriptFileLoading:true}});
 try{
  window.document.write(await readFile(new URL('./index.html',import.meta.url),'utf8'));
  const source=window.document.querySelector('#file-opening-guidance').textContent;
  Function('document','location',source)(window.document,{protocol:'file:'});
  assert.match(window.document.querySelector('#page h1').textContent,/Open the running workspace/);
  assert.equal(window.document.querySelector('#page a').getAttribute('href'),'http://127.0.0.1:5173/#home');
 }finally{await window.happyDOM.close();}
});
